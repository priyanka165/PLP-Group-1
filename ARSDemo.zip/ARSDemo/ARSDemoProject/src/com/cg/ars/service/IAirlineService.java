package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dto.BookingDTO;
import com.cg.ars.dto.FlightDTO;
import com.cg.ars.dto.PassengerDTO;
import com.cg.ars.exception.AirlineException;

public interface IAirlineService {
	
	List<FlightDTO> flightList()throws AirlineException;
	public String getPassword(String name) throws AirlineException;
	public List<BookingDTO> bookingList() throws AirlineException;
	public List<PassengerDTO> passengerList(int userId) throws AirlineException;
	public FlightDTO flightDetails(int flightId)throws AirlineException;
	public int updateFlightInfo(FlightDTO flight)throws AirlineException;
	public int deleteFlightDetails(int flightId)throws AirlineException;
	public int addNewFlight(FlightDTO flight)throws AirlineException;
	public List<PassengerDTO> passengerListById(int flightId) throws AirlineException;

}
