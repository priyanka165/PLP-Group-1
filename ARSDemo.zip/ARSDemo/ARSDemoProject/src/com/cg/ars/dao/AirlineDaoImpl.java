package com.cg.ars.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.BookingDTO;
import com.cg.ars.dto.FlightDTO;
import com.cg.ars.dto.PassengerDTO;
import com.cg.ars.exception.AirlineException;
import com.cg.ars.util.DBUtil;

public class AirlineDaoImpl implements IAirlineDao {
	static Connection connection = null;
	
	static{
		connection = DBUtil.getConnect();
	}
	@Override
	public List<FlightDTO> flightList() throws AirlineException {
		List<FlightDTO> flightList = new ArrayList<FlightDTO>();
		Statement stm;
		ResultSet res;
		try {
			stm = connection.createStatement();
			res = stm.executeQuery("select * from flight_information");
			while(res.next()){
				FlightDTO flight = new FlightDTO();
				flight.setFlightId(res.getInt("flight_id"));
				flight.setAirline(res.getString("airline"));
				flight.setDepartureCity(res.getString("departure_city"));
				flight.setArrivalCity(res.getString("arrival_city"));
				flight.setDepartureTime(res.getString("departure_time"));
				flight.setArrivalTime(res.getString("arrival_time"));
				flight.setNoOfSeats(res.getInt("no_of_seats"));
				flight.setEconomicFare(res.getDouble("eco_fare"));
				flight.setBusinessFare(res.getDouble("Bus_fare"));
				flightList.add(flight);
			}
		} catch (SQLException e) {
			throw new AirlineException("Something went wrong while fetching details");
		}
		return flightList;
	}
	
	@Override
	public String getPassword(String name) throws AirlineException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String query = "SELECT password FROM users WHERE username=?";
		String pass="";
		try {			
			statement = connection.prepareStatement(query);
			statement.setString(1,name);
			resultSet = statement.executeQuery();
			//fetch details if result set is not null
			resultSet.next();
			pass=resultSet.getString("password");		
		} catch (Exception e) {			
			throw new AirlineException("something went wrong while matching login credential...");
		}		
		return pass;
	}
	
	@Override
	public List<BookingDTO> bookingList() throws AirlineException
	{
		List<BookingDTO> bookingList = new ArrayList<BookingDTO>();
		Statement stm;
		ResultSet res;
		try {
			stm = connection.createStatement();
			res = stm.executeQuery("select * from booking_information");
			while(res.next()){
				BookingDTO booking = new BookingDTO();
				booking.setUserId(res.getInt(1));
				booking.setFlightId(res.getInt(2));
				booking.setBookingId(res.getInt(3));
				booking.setBookingDate(res.getDate(4).toLocalDate());
				booking.setNoOfPassengers(res.getInt(5));
				booking.setClassType(res.getString(6));
				booking.setTotalFare(res.getDouble(7));
				bookingList.add(booking);
			}
		}catch (SQLException e) {
			throw new AirlineException("Something went wrong while fetching booking details");
		}
		return bookingList;
	}

	@Override
	public List<PassengerDTO> passengerList(int userId) throws AirlineException {
		List<PassengerDTO> passengerList = new ArrayList<PassengerDTO>();
		PreparedStatement pstm;
		String query = "select * from passengers where user_id=?";
		ResultSet res;
		try {
			pstm = connection.prepareStatement(query);
			pstm.setInt(1,userId);
			res = pstm.executeQuery();
			while(res.next()){
				PassengerDTO passenger = new PassengerDTO();
				passenger.setUserId(res.getInt(1));
				passenger.setPassengerId(res.getInt(2));
				passenger.setPassengerName(res.getString(3));
				passenger.setPassengerAge(res.getInt(4));
				passenger.setPassengerGender(res.getString(5));
				passengerList.add(passenger);
			}
		}catch (SQLException e) {
			throw new AirlineException("Something went wrong while fetching Passenger details");
		}
		return passengerList;
	}

	@Override
	public FlightDTO flightDetails(int flightId) throws AirlineException {
		FlightDTO flight = new FlightDTO();
		PreparedStatement pstm;
		String query = "select * from flight_information where flight_id=?";
		ResultSet res;
		try {
			pstm = connection.prepareStatement(query);
			pstm.setInt(1,flightId);
			res = pstm.executeQuery();
			res.next();
			flight.setFlightId(res.getInt(1));
			flight.setAirline(res.getString(2));
			flight.setDepartureCity(res.getString(3));
			flight.setArrivalCity(res.getString(4));
			flight.setDepartureTime(res.getString(5));
			flight.setArrivalTime(res.getString(6));
			flight.setNoOfSeats(res.getInt(7));
			flight.setBusinessFare(res.getDouble(8));
			flight.setEconomicFare(res.getDouble(9));
		}catch (SQLException e) {
			throw new AirlineException("Something went wrong while fetching flight details by Id.");
		}
		return flight;
	}

	@Override
	public int updateFlightInfo(FlightDTO flight) throws AirlineException {
		String query = "UPDATE flight_information SET "
				+ "airline=?,departure_city=?,arrival_city=?,"
				+ "departure_time=?,arrival_time=?,"
				+ "no_of_seats=?,Bus_fare=?,eco_fare=? WHERE flight_id=?";
		PreparedStatement pstm;
		int res;
		try {
			pstm = connection.prepareStatement(query);
			pstm.setString(1, flight.getAirline());
			pstm.setString(2, flight.getDepartureCity());
			pstm.setString(3, flight.getArrivalCity());
			pstm.setString(4, flight.getDepartureTime());
			pstm.setString(5, flight.getArrivalTime());
			pstm.setInt(6, flight.getNoOfSeats());
			pstm.setDouble(7, flight.getBusinessFare());
			pstm.setDouble(8, flight.getEconomicFare());
			pstm.setInt(9, flight.getFlightId());
			res = pstm.executeUpdate();
		}catch (SQLException e) {
			throw new AirlineException("Something went wrong while updating flight details.");
		}
		return res;
	}

	@Override
	public int deleteFlightDetails(int flightId) throws AirlineException {
		String query = "DELETE from flight_information WHERE flight_id=?";
		PreparedStatement pstm;
		int res;
		try {
			pstm = connection.prepareStatement(query);
			pstm.setInt(1, flightId);
			res = pstm.executeUpdate();
		}catch (SQLException e) {
			throw new AirlineException("Something went wrong while deleting flight details.");
		}
		return res;
	}

	@Override
	public int addNewFlight(FlightDTO flight) throws AirlineException {
		String query = "INSERT INTO flight_information VALUES (?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstm;
		int res;
		try {
			pstm = connection.prepareStatement(query);
			pstm.setInt(1, flight.getFlightId());
			pstm.setString(2, flight.getAirline());
			pstm.setString(3, flight.getDepartureCity());
			pstm.setString(4, flight.getArrivalCity());
			pstm.setString(5, flight.getDepartureTime());
			pstm.setString(6, flight.getArrivalTime());
			pstm.setInt(7, flight.getNoOfSeats());
			pstm.setDouble(8, flight.getBusinessFare());
			pstm.setDouble(9, flight.getEconomicFare());
			res = pstm.executeUpdate();
		}catch (SQLException e) {
			throw new AirlineException("Something went wrong while updating flight details.");
		}
		return res;
	}

	@Override
	public List<PassengerDTO> passengerListById(int flightId)
			throws AirlineException {
		List<PassengerDTO> passengerList = new ArrayList<PassengerDTO>();
		PreparedStatement pstm;
		String query = "select * from passengers where user_id="
				+ "(select user_id from booking_information where"
				+ " flight_id=?)";
		ResultSet res;
		try {
			pstm = connection.prepareStatement(query);
			pstm.setInt(1,flightId);
			res = pstm.executeQuery();
			while(res.next()){
				PassengerDTO passenger = new PassengerDTO();
				passenger.setUserId(res.getInt(1));
				passenger.setPassengerId(res.getInt(2));
				passenger.setPassengerName(res.getString(3));
				passenger.setPassengerAge(res.getInt(4));
				passenger.setPassengerGender(res.getString(5));
				passengerList.add(passenger);
			}
		}catch (SQLException e) {
			throw new AirlineException("Something went wrong while fetching Passenger details");
		}
		return passengerList;
	}
}
